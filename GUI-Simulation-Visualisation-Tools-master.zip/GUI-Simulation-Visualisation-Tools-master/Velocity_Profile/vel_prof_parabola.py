from tkinter import *
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import math

root = Tk()

def callback(event):
    print (event.x, event.y)

root.title("Velocity profile for two immiscible viscous fluids")
root.configure(background='white')

label1 = Label(root, text="Velocity profile for two immiscible viscous fluids", fg="green", font="Helvetica 22 bold italic underline",bg='white'                                                                                                 )
label1.place(x=290, y=0)

label1 = Label(root, text="*1 cp = 0.001 Pa.s", bg='white',fg="red", font="times 15")
label1.place(x=970, y=220)


#---------------------------------------------------------------------------

c3=Canvas(root,height=200,width=220,bg='white')
c3.create_line(111,2,111,600)
label1 = Label(c3, text="Water \n Milk \n Vinegar \n Fruit Juice \n Oil fuel \n Glycerin \n Paraffin \n Honey",
bg='white', fg="black", font="times 15")
label1.place(x=10,y=10)

label2=Label(c3,text="1 cP \n 2 cP \n 12cP \n 55 cP \n 210 cP  \n 648 cP \n 3000 cP  \n  10,000cP"
,bg='white', fg="black", font="times 15")
label2.place(x=120,y=10)
c3.bind("<Button-1>", callback)
c3.place(x=720, y=60)
#----------------------------------------------------------------------------------


label1 = Label(root, text="Viscosity of  fluid, μ₁ : ", bg='white',fg="blue", font="times 15")
label1.place(x=30, y=150)
u= Entry(root, width =10,borderwidth=5, bg='white')
u.place(x=220,y=155)

label1 = Label(root, text="Velocity of upper plate, v : ", bg='white',fg="blue", font="times 15")
label1.place(x=30, y=120)
v= Entry(root, width =10,borderwidth=5, bg='white')
v.place(x=255,y=120)

#---------------------------------------------------------------

label1 = Label(root, text="Fluid height, h₁ (m)", bg='white',fg="blue", font="times 15")
label1.place(x=30, y=40)

scroll1= Scale(root, from_= 0.0, to = 0.7, length = 180,resolution = 0.01,orient=HORIZONTAL, activebackground="orange")
scroll1.configure(background='orange')
scroll1.place(x=30, y=70)

button1 = Button(root, text="Solve",width=7, height=1,fg="red",font="times 15",command=lambda:solve())
button1.place(x=300, y=195)


tkVar1= StringVar(root)
choice1 = {'Linear (Ideal)' , 'Parabolic (Actual)'}
tkVar1.set('Linear (Ideal)')
menu = OptionMenu(root, tkVar1, *choice1)
menu.config(font=('Times',(13)), bg='orange', width=15,height = 1)
menu.place(x=50, y=200)

def solve():
    if(tkVar1.get() == 'Parabolic (Actual)'):
        solve_para()
    else:
        solve_linear()

def solve_para():
    nwin=Toplevel()
    nwin.geometry("300x100")
    Label(nwin, text="Please enter value of dy/dx",font=10).pack()
    e=Entry(nwin)
    e.pack()
    bt=Button(nwin,text='Solve',command=lambda:okk()).pack()

    def okk():
        dydx=float(e.get())
        solve_parabola(dydx)
        nwin.destroy()
    
    nwin.mainloop() 

def solve_linear():

    c90=Canvas(root,width=100,height=30,bg='white')
    c90.create_line(0,10,50,10,arrow=BOTH,width=3)
    c90.place(x=10,y=10)

    cnvs = Canvas(root, width=300, height=50, bg='yellow')
    label = Label(cnvs,text="Please enter correct values",fg='red',bg='yellow',font = 3)
    label.place(x=10,y=10)
    cnvs.place(x=400,y=400)

    h=scroll1.get()
    h2 = 1.0 - h
    viscosity = float(u.get())
    velocity = float(v.get())
    tau1=viscosity * velocity

#-----------------------------------------------------------------
#
#               x1,y1----------x4,y4
#                 |             |
#                 |             |
#                 |             |
#               x2,y2----------x3,y3
#
#------------------------------------------------------   
    
    h0 = 18 * h * 10
    c2=Canvas(root,width=300,height=180,bg='white')
    c2.create_polygon(0,0,0,180 - h0,300,180 - h0,300,0, fill='maroon2')
    c2.create_polygon(0,180 - h0 , 0,180,300,180,300,180 - h0, fill='lawn green')

#------------------------------- Plates --------------------------- 
    c2.create_line(0,3,1000,3,width=10,fill='slategray')
    c2.create_line(0,180,1000,180,width=10,fill='slategray')
    #------------------------------- Plates ---------------------------
    
    c2.create_line(196,7,298,7,width=5,arrow=LAST,fill='black')
    x_q1=(196+298)/2 -40
    y_q1=10
    lb89=Label(c2,text='v1 = %.1f m/s' %velocity,bg='maroon2')
    lb89.place(x=x_q1,y=y_q1)


    c2.create_line(70,3,70,180 - h0,arrow=BOTH,width=2)
    c2.create_line(50,180-h0,50,176,arrow=BOTH,width=2)


    #---------------------------------------------------------------

    y_v1 = (180 - h0 + 3)/2 - 5
    x_v1= 70 +3

    x_v2=50+3
    y_v2=(180 - h0 + 176)/2

    lb1= Label(c2,text='h1                   μ₁ = %.2f' %viscosity,bg='maroon2')
    lb1.place(x=x_v1,y=y_v1) 
    
    lb2= Label(c2,text='h2                   μ = 55.00 cP',bg='lawn green')
    lb2.place(x=x_v2,y=y_v2)

    c2.bind("<Button-1>", callback)
    c2.place(x=405,y=65)


#--------------------------------------------------------------         

    canvas = Canvas(root, width=1300, height=500, bg='white')
    canvas.place(x=10,y=250)
    canvas.create_polygon((70,(368-h*320) -10,70,368,545,368,545,(368-h*320) -10), fill='lawn green')
    canvas.create_polygon((70,33,70,(368-h*320) -10,545,(368-h*320) -10,545,33), fill='maroon2')

# -------------------------Boundary diagram-------------------
    canvas.create_line(70, 368, 545, 368 , width =15, fill='gainsboro')
    canvas.create_line(70, 33, 545, 33 , width =15, fill='gainsboro')
    canvas.create_line(70, 360, 70, 40 , width =3, fill='gainsboro')
    canvas.create_line(545, 360, 545, 40 , width =3, fill='gainsboro')

    canvas.create_line(70, 360 , 60, 360 , width = 1, fill='black')
    lb= Label(canvas, text='0.0',bg = 'white',font=("Times")).place(x=30,y=345)
    canvas.create_line(70, 296 , 60, 296 , width = 1, fill='black')
    lb= Label(canvas, text='0.2',bg = 'white',font=("Times")).place(x=30,y=280)
    canvas.create_line(70, 232 , 60, 232 , width = 1, fill='black')
    lb= Label(canvas, text='0.4',bg = 'white',font=("Times")).place(x=30,y=215)
    canvas.create_line(70, 168 , 60, 168 , width = 1, fill='black')
    lb= Label(canvas, text='0.6',bg = 'white',font=("Times")).place(x=30,y=150)
    canvas.create_line(70, 104 , 60, 104 , width = 1, fill='black')
    lb= Label(canvas, text='0.8',bg = 'white',font=("Times")).place(x=30,y=90)
    canvas.create_line(70, 40 , 60, 40 , width = 1, fill='black')
    lb= Label(canvas, text='1.0',bg = 'white',font=("Times")).place(x=30,y=25)
    canvas.create_line(71,360,544,41,width=3)

    canvas.create_line(71,211,295,211,width=2,arrow=LAST)
    canvas.create_line(71,297,161,297,width=2,arrow=LAST)
    canvas.create_line(71,150,386,150,width=2,arrow=LAST)
    canvas.create_line(71,265,207,265,width=2,arrow=LAST)
    canvas.create_line(71,75,491,75,width=2,arrow=LAST)
    canvas.create_line(71,322,125,322,width=2,arrow=LAST)
    canvas.create_line(71,107,448,108,width=2,arrow=LAST)
    canvas.create_line(71,180,343,180,width=2,arrow=LAST)
    canvas.create_line(71,232,261,232,width=2,arrow=LAST)
    canvas.create_line(71,107,448,108,width=2,arrow=LAST)
    canvas.create_line(71,42,540,42,width=2,arrow=LAST)
    canvas.bind("<Button-1>", callback)
#---------------------------------------------------------------------------
    x1=[]
    x2=[]
    Q=[]

    y1=viscosity
    y2=55

    N=int(scroll1.get() * 100)
    visc = int(u.get())


    for i in range(0,N,1):
        x1.append(i*0.01)
        Q.append(visc)

    for i in range(N-1,100,1):
        x1.append(i*0.01)
        Q.append(55)

    fig = Figure(figsize=(7,3.5))
    a = fig.add_subplot(111)
    a.plot(x1,Q,color='red')

    a.set_xlabel('y (m)',color='green',labelpad=0) 
    a.set_ylabel('τ (Pa)',color='green')


    canvas2 = Canvas(c2, width=7.5, height=3.5)
    canvas2 = FigureCanvasTkAgg(fig, master=root)
    canvas2.get_tk_widget().place(x=610,y=260)
    canvas2.draw()

#----------------------------------------------------------------------#

def solve_parabola(dydx):
    cnvs = Canvas(root, width=300, height=50, bg='yellow')
    label = Label(cnvs,text="Please enter correct values",fg='red',bg='yellow',font =3)
    label.place(x=10,y=10)
    cnvs.place(x=400,y=400)

    canvas = Canvas(root, width=1300, height=500, bg='white')
    canvas.place(x=10,y=250)

    h=scroll1.get()
    h2 = 1.0 - h
    viscosity = float(u.get())
    velocity = float(v.get())
    tau1=viscosity * velocity

    #-----------------------------------Parabolic Graph -------------------

    xp=[]
    yp=[]   

    P = - dydx / (2*viscosity*velocity)

    for temp in range(0,100,1):
        y = temp * 0.01
        u_v = y + P*y*(1-y)
        xp.append(u_v)
        yp.append(y)


    fig = Figure(figsize=(7,3.5))
    ap = fig.add_subplot(111)

    ap.plot(xp,yp,color='red')

    canvas2 = Canvas(canvas, width=7.5, height=3.5)
    canvas2 = FigureCanvasTkAgg(fig, master=root)
    canvas2.get_tk_widget().place(x=80,y=300)
    canvas2.draw()

#-----------------------------------------------------------------
#
#               x1,y1----------x4,y4
#                 |             |
#                 |             |
#                 |             |
#               x2,y2----------x3,y3
#
#------------------------------------------------------   
    
    h0 = 18 * h * 10
    c2=Canvas(root,width=300,height=180,bg='white')
    c2.create_polygon(0,0,0,180 - h0,300,180 - h0,300,0, fill='maroon2')
    c2.create_polygon(0,180 - h0 , 0,180,300,180,300,180 - h0, fill='lawn green')

#------------------------------- Plates --------------------------- 
    c2.create_line(0,3,1000,3,width=10,fill='slategray')
    c2.create_line(0,180,1000,180,width=10,fill='slategray')
    #------------------------------- Plates ---------------------------
    
    c2.create_line(196,10,298,10,width=2,arrow=LAST,fill='black')
    x_q1=(196+298)/2 - 30
    y_q1=15
    lb89=Label(c2,text='v1 = %.1f m/s' %velocity,bg='maroon2')
    lb89.place(x=x_q1,y=y_q1)


    c2.create_line(70,3,70,180 - h0,arrow=BOTH,width=2)
    c2.create_line(50,180-h0,50,176,arrow=BOTH,width=2)

    y_v1 = (180 - h0 + 3)/2
    x_v1= 70 +3

    x_v2=50+3
    y_v2=(180 - h0 + 176)/2

    lb1= Label(c2,text='h1',bg='maroon2')
    lb1.place(x=x_v1,y=y_v1)
    
    lb2= Label(c2,text='h2',bg='lawn green')
    lb2.place(x=x_v2,y=y_v2)

    c2.bind("<Button-1>", callback)
    c2.place(x=405,y=65)

#--------------------------------------------------------------         


root.state('zoomed')

root.mainloop()
