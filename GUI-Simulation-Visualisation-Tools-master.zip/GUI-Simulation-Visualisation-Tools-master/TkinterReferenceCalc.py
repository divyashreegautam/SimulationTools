from tkinter import *
#Importing all the functionalities of Tkinter module

import math
#Obviously xD

#Class calc is where all the calculations and important stuff happens

class calc:
	#Creating a function to convert 'x' with '*' and '÷' with '/'
	def greplace(ch):
		#ch is constructor variable
		#var is just a variable
		ch.expression = ch.var.get()
		ch.newtext = ch.expression.replace(ch.newdiv,'/')
		ch.newtext = ch.newtext.replace('x','*')

	def equals(ch):
		"""When the user clicks equal button"""

		ch.greplace()
		try:
			ch.value = eval(ch.newtext)
			#Evaluate the expression using in-built eval function
			#Exception handling
		except SyntaxError or NameError :
			#To clear input screen after all the data has been entered
			ch.var.delete(0,END)
			#If we recieve an invalid input
			ch.var.insert(0,'Invalid Input!')
		else:
			ch.var.delete(0,END)
			ch.var.insert(0,ch.value)

	def sqrt(ch):
		"""Squareroot method"""
		ch.greplace()
		try:
			ch.value = eval(ch.newtext)
		except SuntaxError or NameError:
			ch.var.delete(0,END)
			ch.var.insert(0,'Invalid Input!')
		else:
			ch.sqrtval=math.sqrt(ch.value)
			#Finding square with sqrt() from math module
			ch.var.delete(0,END)
			ch.var.insert(0,ch.sqrtval)

	def square(ch):
		"""square method"""
		ch.greplace()
		try:
			ch.value= eval(ch.newtext)
		except SyntaxError or NameError:
				ch.var.delete(0,END)
				ch.var.insert(0,'Invalid Input!')
		else:
			ch.sqval= math.pow(ch.value,2)
			ch.var.delete(0,END)
			ch.var.insert(0,ch.sqval)

	def clearall(ch):
		"""When the user clicks clear button, clear Input screen"""
		ch.var.delete(0,END)

	def clear1(ch):

		ch.txt= ch.var.get()[: -1]
		ch.var.delete(0,END)
		ch.var.insert(0,ch.txt)
	
	def action(ch,argi):

	   """ Printing to the screen the character entered by the user"""
	   ch.var.insert(END,argi)

	def __init__(ch,master):
		"""Constructor Method"""
		master.title("Bhuwan's Calculator")
		#Geometry allows us to explicitly set the position and size of the window
		master.geometry()
		ch.var=Entry(master)
		ch.var.grid(row=0, column=0, columnspan=6,pady=3)
		ch.var.focus_set()
		#Sets focus on the Input screen

		ch.div='÷'
		ch.newdiv=ch.div

		#Generating buttons
		Button(master,text="=",width=10,command=lambda:ch.equals()).grid(row=4, column=4,columnspan=2)
		Button(master,text='AC',width=3,command=lambda:ch.clearall()).grid(row=1, column=4)
		Button(master,text='C',width=3,command=lambda:ch.clear1()).grid(row=1, column=5)
		Button(master,text="+",width=3,command=lambda:ch.action('+')).grid(row=4, column=3)
		Button(master,text="x",width=3,command=lambda:ch.action('x')).grid(row=2, column=3)
		Button(master,text="-",width=3,command=lambda:ch.action('-')).grid(row=3, column=3)
		Button(master,text="÷",width=3,command=lambda:ch.action(ch.newdiv)).grid(row=1, column=3) 
		Button(master,text="%",width=3,command=lambda:ch.action('%')).grid(row=4, column=2)
		Button(master,text="7",width=3,command=lambda:ch.action('7')).grid(row=1, column=0)
		Button(master,text="8",width=3,command=lambda:ch.action(8)).grid(row=1, column=1)
		Button(master,text="9",width=3,command=lambda:ch.action(9)).grid(row=1, column=2)
		Button(master,text="4",width=3,command=lambda:ch.action(4)).grid(row=2, column=0)
		Button(master,text="5",width=3,command=lambda:ch.action(5)).grid(row=2, column=1)
		Button(master,text="6",width=3,command=lambda:ch.action(6)).grid(row=2, column=2)
		Button(master,text="1",width=3,command=lambda:ch.action(1)).grid(row=3, column=0)
		Button(master,text="2",width=3,command=lambda:ch.action(2)).grid(row=3, column=1)
		Button(master,text="3",width=3,command=lambda:ch.action(3)).grid(row=3, column=2)
		Button(master,text="0",width=3,command=lambda:ch.action(0)).grid(row=4, column=0)
		Button(master,text=".",width=3,command=lambda:ch.action('.')).grid(row=4, column=1)
		Button(master,text="(",width=3,command=lambda:ch.action('(')).grid(row=2, column=4)
		Button(master,text=")",width=3,command=lambda:ch.action(')')).grid(row=2, column=5)
		Button(master,text="√",width=3,command=lambda:ch.squareroot()).grid(row=3, column=4)
		Button(master,text="x²",width=3,command=lambda:ch.square()).grid(row=3, column=5)
#Main
root = Tk()
obj=calc(root) #object instantiated
root.mainloop()
